package Lab_problems;
 interface library {

    public void drawbook();
    public void returnbook();
    public void checkstatus();
    public void reservebook();


}